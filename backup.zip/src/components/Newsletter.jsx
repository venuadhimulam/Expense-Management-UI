import { Send } from "@material-ui/icons";
import React from "react";
import styled from "styled-components";
import { mobile } from "../responsive";

const Container = styled.div`
  padding: 30px;
  background-color: antiquewhite;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  ${mobile({ padding: "10px" })}
`;

const Title = styled.h3`
  font-size: 25px;
  margin-bottom: 20px;
  ${mobile({ fontSize: "40px" })}
`;

const Div = styled.div`
  padding: 20px;
`;

const Desc = styled.p`
  font-size: 15px;
  font-weight: 300;
  margin-bottom: 20px;
  ${mobile({ fontSize: "15px" })}
`;

const InputContainer = styled.div`
  width: 50%;
  height: 40px;
  background-color: white;
  display: flex;
  justify-content: space-between;
  border: 1px solid lightgrey;
  ${mobile({ width: "100%" })}
`;

const Input = styled.input`
  border: none;
  flex: 8;
  padding-left: 20px;
  ${mobile({ flex: "9" })}
`;

const Button = styled.button`
  flex: 2;
  border: none;
  background: teal;
  color: white;
  ${mobile({ flex: "1" })}
`;

const Newsletter = () => {
  return (
    <Container>
      <Title>About Cleveland State University</Title>
      <Div>
        <Desc>
          Founded in 1964, Cleveland State University is a public research
          institution that provides a dynamic setting for Engaged Learning. With
          17,000-plus students, ten colleges and schools, and more than 175
          academic programs, CSU was again chosen for 2019 as one of America’s
          best universities by U.S. News World Report. Find more information at
          www.csuohio.edu.
        </Desc>
      </Div>
    </Container>
  );
};

export default Newsletter;
