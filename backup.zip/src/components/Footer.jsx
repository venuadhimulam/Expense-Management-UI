import { Facebook, LinkedIn, Twitter } from "@material-ui/icons";
import React from "react";
import styled from "styled-components";

const Container = styled.div`
  display: flex;
  color: white;
  background-color: #233750;
`;

const Left = styled.div`
  flex: 1;
  margin-left: 10px;
  padding: 5px;
`;

const Logo = styled.h6`
  flex: 1;
  margin: 0;
  padding: 10px;
  font-size: 15px;
`;

const SocialContainer = styled.div`
  display: flex;
  float: right;
  padding: 10px;
`;

const SocialIcon = styled.a`
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 20px;
  cursor: pointer;
`;

const Center = styled.div`
  flex: 1;
  padding: 5px;
`;

const Right = styled.div`
  flex: 1;
  padding: 5px;
`;

const Footer = () => {
  return (
    <Container>
      <Left>
        <Logo>Copyright ©️2020, All rights reserved.</Logo>
      </Left>
      <Center></Center>
      <Right>
        <SocialContainer>
          <SocialIcon href="https://www.facebook.com/Drughelp.careApp/">
            <Facebook />
          </SocialIcon>
          <SocialIcon href="https://twitter.com/DrughelpC">
            <Twitter />
          </SocialIcon>
          <SocialIcon href="https://www.linkedin.com/company/drughelp-care/">
            <LinkedIn />
          </SocialIcon>
        </SocialContainer>
      </Right>
    </Container>
  );
};

export default Footer;
