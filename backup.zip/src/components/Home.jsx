import React from "react";
import styled from "styled-components";
import ExpenseForm from "./ExpenseForm";
import { mobile } from "../responsive";
import ExpenseTable from "./ExpenseTable";
import { AddToPhotosOutlined, ListAltRounded } from "@material-ui/icons";

const Container = styled.div`
  width: 100%;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #b6b6b6;
  ${mobile({ flexDirection: "column", height: "100%" })}
`;

const Wrapper = styled.div`
  width: 70%;
  padding: 20px;
  height: 100%;
  background: white;
`;

const AddExpenses = styled.div`
  width: 70%;
  padding: 20px;
  height: 100%;
  background: white;
  flex: 1;
  ${mobile({ width: "100%" })}
`;

const ListOfExpenses = styled.div`
  width: 70%;
  padding: 20px;
  height: 100%;
  background: white;
  flex: 2;
  ${mobile({ width: "100%" })}
`;

const Tilte = styled.h2`
  font-size: 20px;
  font-weight: 300;
`;

const TitleDiv = styled.div`
  display: flex;
  background-color: #233750;
  color: white;
  padding: 5px;
  ${mobile({ marginBottom: "5px" })}
`;

const Add = styled(AddToPhotosOutlined)`
  font-size: 25px;
  margin-right: 10px;
`;

const List = styled(ListAltRounded)`
  font-size: 25px;
  margin-right: 10px;
`;

const Home = () => {
  return (
    <Container>
      <AddExpenses>
        <TitleDiv>
          <div>
            <Add className="text-white" />
          </div>
          <Tilte>Add Expenses</Tilte>
        </TitleDiv>
        <ExpenseForm />
      </AddExpenses>
      <ListOfExpenses>
        <TitleDiv>
          <div>
            <List className="text-white" />
          </div>
          <Tilte>List of Expenses</Tilte>
        </TitleDiv>
        <ExpenseTable />
      </ListOfExpenses>
    </Container>
  );
};

export default Home;
