import React, { useState, Component } from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";

import styled from "styled-components";
import axios from "axios";
import { mobile } from "../responsive";

const Container = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  background: #b6b6b6;
  ${mobile({ height: "auto" })}
`;

const Wrapper = styled.div`
  width: 70%;
  padding: 20px;
  height: 100%;
  background: white;
  ${mobile({ width: "100%" })}
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
`;

const FormDiv = styled.div`
  display: flex;
  flex-direction: "column";
  ${mobile({ flexDirection: "column" })}
`;

const Left = styled.div`
  flex: 1;
  padding: 5px;
`;

const Center = styled.div`
  flex: 1;
  padding: 5px;
`;

const Input = styled.input`
  flex: 1;
  min-width: 100%;
  margin: 10px 0px;
  padding: 10px;
  outline: none;
  border: 1px solid #192637;
  border-radius: 5px;
`;

const Right = styled.div`
  flex: 1;
  padding: 5px;
`;

const TextArea = styled.textarea`
  resize: none;
  width: 100%;
  flex: 1;
  min-width: 40%;
  margin: 10px 0px;
  padding: 10px;
  outline: none;
  border-radius: 3px;
  border: 1px solid #192637;
`;

const Button = styled.button`
  width: 20%;
  background-color: #192637;
  color: white;
  cursor: pointer;
  border-radius: 3px;
  border: none;
  padding: 5px;

  ${mobile({ width: "25%" })}
`;

const ErrorDiv = styled.button`
  border: 1px solid red;
  color: #ff0000 !important;
  padding: 5px;
  margin: 5px;
  border-radius: 5px;
`;

// const ExpenseForm = ({ props }) => {
class ExpenseForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: null,
      price: null,
      description: null,
    };
  }

  componentDidMount() {
    if (this.props && this.props.type && this.props.type === "update") {
      console.log("inside form..", this.props);
      if (this.props.expenseData) {
        let editData = this.props.expenseData;
        this.setState({
          name: editData.name,
          price: editData.price,
          description: editData.description,
        });
      }
    }
  }

  render() {
    // const [name, setName] = useState("");
    // const [price, setPrice] = useState("");
    // const [description, setDescription] = useState("");
    // const [msg, setMsg] = useState("");

    const handleInputChanges = (event) => {
      this.setState({
        name: event,
      });
      // this.setName(event);
      // setName(event);
    };

    const isNumericInput = (event) => {
      const reg = new RegExp("^[+]?([0-9]{0,})*[.]?([0-9]{0,})?$", "g");
      if (event === "" || reg.test(event)) {
        // this.setPrice(event);
        this.setState({
          price: event,
        });
        // setPrice(event);
      }
    };

    const handleTextAreaChanges = (event) => {
      // this.setDescription(event);
      // setDescription(event);
      this.setState({
        description: event,
      });
    };

    console.log(this.props);

    const saveExpenses = (req, res) => {
      if (this.props && this.props.type && this.props.type === "update") {
        let Id =
          this.props && this.props.expenseData && this.props.expenseData.id;
        axios
          .put("http://127.0.0.1:8000/updateExpense/" + Id, {
            name: this.state.name,
            price: this.state.price,
            description: this.state.description,
          })
          .then((res) => {
            // setMsg("Saved Successfully!");
            console.log("Updated Successfully");
          })
          .catch((err) => {
            // setMsg("Please fill proper data!");
            console.log("Updated Error");
          });
      } else {
        axios
          .post("http://127.0.0.1:8000/saveExpense", {
            name: this.state.name,
            price: this.state.price,
            description: this.state.description,
          })
          .then((res) => {
            // setMsg("Saved Successfully!");
            console.log("Saved Successfully");
          })
          .catch((err) => {
            // setMsg("Please fill proper data!");
            console.log("Error");
          });
      }
    };

    return (
      <Container>
        <Wrapper>
          <Form>
            <Left>
              <Box
                component="form"
                sx={{
                  "& > :not(style)": { m: 1, width: "25ch" },
                }}
                noValidate
                autoComplete="off"
              >
                <TextField
                  // id="outlined-basic"
                  label="Outlined"
                  variant="outlined"
                  id="name"
                  value={this.state.name}
                  placeholder="name"
                  onChange={(event) => {
                    handleInputChanges(event.target.value);
                  }}
                  required
                />
              </Box>

              {/* <Input
                id="name"
                value={this.state.name}
                placeholder="name"
                onChange={(event) => {
                  handleInputChanges(event.target.value);
                }}
                required
              /> */}
            </Left>
            <Center>
              <Input
                id="price"
                placeholder="price"
                value={this.state.price}
                onChange={(event) => {
                  isNumericInput(event.target.value);
                }}
                required
              />
            </Center>
            <Right>
              <TextArea
                id="description"
                name="description"
                value={this.state.description}
                placeholder="description"
                onChange={(event) => {
                  handleTextAreaChanges(event.target.value);
                }}
                required
              />
            </Right>
            <Button className="btn" onClick={saveExpenses}>
              Add
            </Button>
          </Form>
        </Wrapper>
      </Container>
    );
  }
}

export default ExpenseForm;
