import React from "react";
import Footer from "./components/Footer";
import Navbar from "./components/Navbar";
import Newsletter from "./components/Newsletter";
import styled from "styled-components";

const Div = styled.div`
  display: flex;
  flex-direction: column;
`;

const App = () => {
  return (
    <Div>
      <Navbar />
      <Newsletter />
      <Footer />
    </Div>
  );
};

export default App;
